export { default as Dashboard } from './Dashboard';
export { default as TasksPage } from './TasksPage';
export { default as ReportsPage } from './ReportsPage';
export { default as SettingsPage } from './SettingsPage'; 